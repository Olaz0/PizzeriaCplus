#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include <dirent.h>
#include <windows.h>



using namespace std;
struct keys {
    string k, v;
};
struct menuItem {
    int number;
    string name;
    double price;
};

vector<keys> keysSetup;
vector<menuItem> menuTab;
string fol;

vector<string> readFile(string fileName) {
    ifstream file;
    file.open(fileName.c_str());
    vector<string> res;
    if (file) {
        string line;
        while (!file.eof()) {
            getline(file, line);
            res.push_back(line);
        }
        file.close();
    }
    return res;
}

void writeFile(vector<string> &vec, string fileName) {
    ofstream file;
    file.open(fileName.c_str(), ios::app | ios::ate);
    for (string a: vec) {
        file << a << endl;
    }
    file.close();
}

string getFromSetup(string klucz) {
    if (keysSetup.size() == 0) {
        string path = "..\\data\\setup.txt";
        keys k;
        auto x = readFile(path);
        if (x.size() == 0) {
            return "Blad wysukiwania 'setup.txt'";
        } else {
            for (int i = 0; i < x.size(); i++) {
                k.k = x[i].substr(0, x[i].find("="));
                x[i].erase(0, x[i].find("=") + 1);
                k.v = x[i];
                keysSetup.push_back(k);
            }
        }
    }
    for (int i = 0; i < keysSetup.size(); i++) {
        if (keysSetup[i].k.find(klucz) != string::npos) return keysSetup[i].v;
    }
    return "NONE";
}

void drawLine(int width, bool endlT) {
    for (int i = 0; i <= width; i++) {
        cout << "-";
    }
    if (endlT == true) {
        cout << endl;
    }
}


void loadMenu(const char *nazwa_sciezki) {
    struct dirent *plik;
    string a;
    vector<string> files;
    DIR *sciezka;
    if ((sciezka = opendir(nazwa_sciezki))) {

        while ((plik = readdir(sciezka))) {
            a = plik->d_name;
            if (a.find(".txt") != string::npos) files.push_back(a);
        }
        closedir(sciezka);
    }
    sort(files.begin(), files.end());
    menuItem item;
    int posNumner = 1;
    for (int i = 0; i < files.size(); i++) {
        string fileMenu = nazwa_sciezki;
        fileMenu = fileMenu + "\\" + files[i];
        auto mf = readFile(fileMenu);
        for (int i = 0; i < mf.size(); i++) {
            string line = mf[i];
            if (line.size() != 0) {
                item.name = line.substr(0, line.find("="));
                line.erase(0, line.find("=") + 1);
                double price = atof(line.c_str());
                item.price = price;
                if (price == -1)item.number = 0;
                else item.number = posNumner++;
                menuTab.push_back(item);
            }
        }
    }
}

string showMenuLineNormalize(string a, int b = 0, double c = 0) {
    string res = "| ";
    if (b == 0) {
        res = res + a;
        while (res.size() < 61) res = res + " ";
        res = res + "|";
    } else {
        string tmp = to_string(b);
        if (tmp.size() < 2) tmp = " " + tmp;
        res = res + tmp + ". " + a;
        tmp = to_string(c);
        tmp.erase(tmp.find(".") + 3, tmp.size());
        while (res.size() + tmp.size() < 60) res = res + ".";
        res = res + tmp + " |";
    }
    return res;
}

void showMenu() {
    int maxPos = 0;
    cout << "-----------------------------MENU------------------------------" << endl;
    for (int i = 0; i < menuTab.size(); i++) {
        if (menuTab[i].number == 0) {
            cout << showMenuLineNormalize(menuTab[i].name) << endl;
        } else {
            if (maxPos < menuTab[i].number) maxPos = menuTab[i].number;
            cout << showMenuLineNormalize(menuTab[i].name, menuTab[i].number, menuTab[i].price) << endl;
        }
    }
    cout << "--------------------------------------------------------------" << endl;

}

string orderLineNormalize(int pos, double val, int pie, string nam) {
    string res = "    - [", tmp = to_string(pos), tmp2;
    if (tmp.size() < 2) tmp = "0" + tmp;
    res = res + tmp + "] " + nam;
    tmp2 = to_string(pie);
    tmp = to_string(val);
    tmp.erase(tmp.find(".") + 3, tmp.size());
    while (res.size() + tmp.size() + tmp2.size() < 40) res = res + ".";
    res = res + "x" + tmp2 + " = " + tmp;
    return res;
}


void order() {
    int maxPos = atoi(getFromSetup("MAXPOS").c_str());
    int t[maxPos + 10]{};
    int nrPoz = 0, countDish = 0;
    bool theEnd;
    vector<string> receipt;
    char ans;
    bool theBegin = true;
    do {
        theEnd = false;
        do {
            showMenu();
            if (!theBegin) {
                if (nrPoz > maxPos || (nrPoz == 0 && !theEnd))
                    cout << "Podales bledna wartosc. Numer powinien byc w zakresie od 0 do " << maxPos << endl;
                else {
                    if (nrPoz != -1) {
                        cout << "Dodano pozycje " << nrPoz << endl;
                        countDish++;
                    } else
                        cout
                                << "\nNIE dodano pozycji do zamowienia. Osiagnieto maksymalna ilosc dan (10) na jedno zamowienie";
                }
                cout << "\nW zamowieniu znajduja sie :";
                for (int i = 1; i < maxPos + 1; i++) if (t[i] > 0) cout << i << "x" << t[i] << "szt. ";
                cout << endl;
            }
            cout
                    << "Prosze wpisac ID dan jakie maja byc dodane do zamowienia.\n Wprowadzenie 0 podowuje przejscie do podsumowania zamowienia\n";
            string poz;
            cin >> poz;
            if (poz == "0") theEnd = true;
            nrPoz = atoi(poz.c_str());
            if (theBegin && nrPoz > 0 && nrPoz <= maxPos) theBegin = false;
            if (countDish < 10) { if (nrPoz > 0 && nrPoz <= maxPos) t[nrPoz]++; }
            else { nrPoz = -1; }
        } while (!theEnd);
        cout << "Podsumowanie zamowienia\n";
        SYSTEMTIME st;
        GetSystemTime(&st);
        string orderDate = (st.wDay < 10 ? "0" : "") + to_string(st.wDay) + "-" + (st.wMonth < 10 ? "0" : "") +
                           to_string(st.wMonth) + "-" + to_string(st.wYear);
        cout << "Data zamowienia " << orderDate << endl << endl << "Zamowiono " << countDish << " dan:" << endl;
        double bill = 0;

        receipt.push_back("DATA: " + orderDate);
        for (int i = 1; i <= maxPos; i++) {
            if (t[i] > 0) {
                for (int j = 0; j < menuTab.size(); j++) {
                    if (i == menuTab[j].number) {
                        string tmp = orderLineNormalize(i, t[i] * menuTab[j].price, t[i], menuTab[j].name);
                        cout << tmp << endl;
                        tmp = to_string(t[i]) + ";" + to_string(menuTab[j].price) + ";" +
                              to_string(t[i] * menuTab[j].price) + ";" + menuTab[j].name;
                        receipt.push_back(tmp);
                        bill += t[i] * menuTab[j].price;
                    }

                }
            }
        }
        string tmp = "SUMA: " + to_string(bill);
        tmp.erase(tmp.find(".") + 3, tmp.size());
        cout << tmp << endl;
        receipt.push_back(tmp);
        cout << "Czy zatwierdzic zamowienie?\n [T] - zatwierdz [N] - usun ";
        ans = 'x';
        do {
            cin >> ans;
            ans = toupper(ans);

        } while (ans != 'T' && ans != 'N');


    } while (ans != 'T' && ans != 'N');
    if (ans == 'T') writeFile(receipt, "..\\data\\sprzedaz\\sprzedaz.txt");


}

string historyNormalizeLine(string id, string dat, string nam, string pri, string val, string bil, string sum) {
    string res = " | ", tmp;//3
    while (id.size() < 4) id = " " + id;//7
    res = res + id + " | " + dat;//10
    while (res.size() < 21) res = res + " ";
    res = res + " | " + nam;
    while (res.size() < 45) res = res + " ";
    res = res + " | ";
    while (pri.size() < 6) pri = " " + pri;
    res = res + pri + " | ";
    while (val.size() < 3) val = " " + val;
    res = res + val + " | ";
    while (bil.size() < 7) bil = " " + bil;
    res = res + bil + " | ";
    while (sum.size() < 8) sum = " " + sum;
    res = res + sum + " | ";
    return res;
}

void showHistory(vector<string> &x) {
    if (x.size() == 0) {
        cout << "\n\nBrak danych do wyswietlenia\n\n";
        return;
    }

    int i = 0, id = 0;
    string data = "", suma = "", dat, nam, pri, val, bil, tmp, idS;
    int a;
    double total = 0;
    cout << " ---------------------------------------------------------------------------------" << endl;
    cout << " |  #   | Data        | Dania                 | Cena   |Ilosc| Wartosc |   Suma   |" << endl;

    while (i < x.size() - 1) {
        if (x[i].find("DATA") != string::npos) {
            cout << " ---------------------------------------------------------------------------------" << endl;
            data = x[i];
            data.erase(0, 6);
            i++;
            id++;
            idS = to_string(id);
        }
        if (x[i].find("SUMA") != string::npos) {
            suma = x[i];
            suma.erase(0, 6);

            total += atof(suma.c_str());
            cout << historyNormalizeLine("", "", "", "SUMA", "", "", suma) << endl;
        } else {

            tmp = x[i];
            val = tmp.substr(0, tmp.find(";"));
            tmp.erase(0, tmp.find(";") + 1);
            pri = tmp.substr(0, tmp.find(";"));
            pri.erase(pri.find(".") + 3, pri.size());
            tmp.erase(0, tmp.find(";") + 1);
            bil = tmp.substr(0, tmp.find(";"));
            bil.erase(bil.find(".") + 3, bil.size());
            tmp.erase(0, tmp.find(";") + 1);
            nam = tmp;
            cout << historyNormalizeLine(idS, data, nam, pri, val, bil, "-") << endl;
        }
        i++;
        suma = "";
        data = "";
        idS = "";
    }
    cout << " ---------------------------------------------------------------------------------" << endl;
    tmp = to_string(total);
    tmp.erase(tmp.find(".") + 3, tmp.size());
    tmp = "SUMA " + tmp;
    while (tmp.size() < 79) tmp = " " + tmp;
    cout << " |" << tmp << " | " << endl;
    cout << " ---------------------------------------------------------------------------------" << endl;
}

void history() {
    int cOrder = 0;
    string path = "..\\data\\sprzedaz\\sprzedaz.txt";
    auto x = readFile(path);
    for (string y: x) {//cout<<y<<endl;
        if (y.find("DATA") != string::npos) cOrder++;
    }
    cout << "Lista zamowien [" << cOrder << "]\n";
    showHistory(x);
    cout << "Nacisnij ENTER aby kontynuowac...";
    cin.ignore();
    getchar();
}

void historyByDate() {
    string date = "", tmp;
    int d, m, y;
    bool dateOK = true;
    int dt[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    do {
        if (!dateOK) cout << "Podana data jest niepoprawna\n";
        dateOK = true;
        cout << "Prosze podac date, z ktorej mam wybrac sprzedaz, w kolejnosci dzien,miesiac,rok np.: 25-01-2022\n";
        cin >> date;
        d = atoi(date.substr(0, date.find("-")).c_str());
        date.erase(0, date.find("-") + 1);
        m = atoi(date.substr(0, date.find("-")).c_str());
        date.erase(0, date.find("-") + 1);
        y = atoi(date.c_str());
        if (y < 2000) dateOK = false;
        if (m < 1 || m > 12) dateOK = false;
        if (m != 2 && (d > dt[m] || d < 1)) dateOK = false;
        else {
            if (m == 2) {
                if (y % 4 == 0) { if (d > 29 || d < 1) dateOK = false; }
                else {
                    if (d > 28 || d < 1)
                        dateOK = false;
                };
            };
        }
    } while (!dateOK);
    date = (d < 10 ? "0" : "") + to_string(d) + "-" + (m < 10 ? "0" : "") + to_string(m) + "-" + to_string(y);
    vector<string> choice;
    bool addToChoice = false;
    int cO = 0, cC = 0;
    string path = "..\\data\\sprzedaz\\sprzedaz.txt";
    auto x = readFile(path);
    for (string y: x) {
        if (y.find("DATA") != string::npos) {
            cO++;
            if (y.find(date) != string::npos) {
                addToChoice = true;
                cC++;
            } else addToChoice = false;
        }
        if (addToChoice) choice.push_back(y);
    }
    if (choice.size() == 0) {
        cout << "Empty list\n";
    } else {
        choice.pop_back();
        choice.push_back(" ");
        cout << "Lista zamowien [ " << cC << " / " << cO << " ] spelnia warunek " << date << "]" << endl << endl;
        showHistory(choice);
        cout << "Nacisnij ENTER aby kontynuowac...";
        cin.ignore();
        getchar();
    };
}


void mainMenu(string rName) {
    char answer = '0';
    do {
        do {

            drawLine(20, true);
            cout << rName << endl;
            drawLine(20, true);
            cout << "Witaj w programie Restauracji 1.0\n" << endl;
            cout << "Opcje: " << endl;
            cout << "[0] Zloz zamowienie" << endl;
            cout << "[1] Historia zamowien" << endl;
            cout << "[2] Historia zamowien dla danego dnia" << endl;
            cout << "[3] Zamknij program\n" << endl;

            if (answer != '0' && answer != '1' && answer != '2' && answer != '3')
                cout << "Bledna odpowiedz. Prosze wybrac 1, 2, 3 lub 4" << endl;

            cout << "Prosze podac opcje: " << endl;
            cin >> answer;

        } while (answer != '0' && answer != '1' && answer != '2' && answer != '3');
        switch (answer) {
            case '0':
                order();
                break;
            case '1':
                history();
                break;
            case '2':
                historyByDate();
                break;
        }
    } while (answer != '3');
}


int main(int argc, char **argv) {
    string restaurantName = getFromSetup("NAME");
    string fol = "..\\data\\menu";
    loadMenu(fol.c_str());

    if (restaurantName == "Blad(1)") {
        cout << "Brak pliku setup. \nProgram zostanie zamkniety. \nNacisnij ENTER";
        getchar();
        return 0;
    }
    if (menuTab.size() == 0) {
        cout << "Fatalny blad. \nBrak plikow z menu\nProgram zostanie zamkniety. \nNacisnij ENTER";
        getchar();
        return 0;
    }

    char ansE = 'N';
    do {
        mainMenu(restaurantName);
        cout << "Czy na pewno zakonczyc prace? [T] [N] ";
        cin >> ansE;
        ansE = toupper(ansE);
    } while (ansE != 'T');
    cout << "Dziekuje za wspolprace. Do widzenia";
    return 0;
}
